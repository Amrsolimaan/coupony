import 'package:hive/hive.dart';
import 'package:equatable/equatable.dart';

/// User preferences model for onboarding
/// Stores selected category keys (language-agnostic)
@HiveType(typeId: 1) // Unique typeId for Hive
class UserPreferencesModel extends Equatable {
  @HiveField(0)
  final List<String> selectedCategories;

  @HiveField(1)
  final DateTime timestamp;

  @HiveField(2)
  final bool isSynced;

  const UserPreferencesModel({
    required this.selectedCategories,
    required this.timestamp,
    this.isSynced = false,
  });

  /// Factory constructor for creating from JSON (for API)
  factory UserPreferencesModel.fromJson(Map<String, dynamic> json) {
    return UserPreferencesModel(
      selectedCategories: List<String>.from(json['selected_categories'] ?? []),
      timestamp: DateTime.parse(json['timestamp'] as String),
      isSynced: json['is_synced'] as bool? ?? false,
    );
  }

  /// Convert to JSON (for API)
  Map<String, dynamic> toJson() {
    return {
      'selected_categories': selectedCategories,
      'timestamp': timestamp.toIso8601String(),
      'is_synced': isSynced,
    };
  }

  /// Create empty preferences
  factory UserPreferencesModel.empty() {
    return UserPreferencesModel(
      selectedCategories: const [],
      timestamp: DateTime.now(),
      isSynced: false,
    );
  }

  /// Copy with method
  UserPreferencesModel copyWith({
    List<String>? selectedCategories,
    DateTime? timestamp,
    bool? isSynced,
  }) {
    return UserPreferencesModel(
      selectedCategories: selectedCategories ?? this.selectedCategories,
      timestamp: timestamp ?? this.timestamp,
      isSynced: isSynced ?? this.isSynced,
    );
  }

  @override
  List<Object?> get props => [selectedCategories, timestamp, isSynced];

  @override
  String toString() =>
      'UserPreferencesModel(categories: $selectedCategories, synced: $isSynced)';
}
