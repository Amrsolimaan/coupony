import 'package:dartz/dartz.dart';
import '../../../../core/errors/failures.dart';
import '../../data/models/user_preferences_model.dart';

/// Repository interface for onboarding preferences
abstract class OnboardingRepository {
  /// Save preferences locally (before authentication)
  Future<Either<Failure, void>> savePreferencesLocally(
    List<String> selectedCategories,
  );

  /// Get local preferences
  Future<Either<Failure, UserPreferencesModel?>> getLocalPreferences();

  /// Clear local preferences
  Future<Either<Failure, void>> clearLocalPreferences();

  /// Check if preferences exist locally
  Future<bool> hasLocalPreferences();

  /// Sync preferences to backend (after authentication)
  /// ⚠️ TODO: Implement when API is available
  Future<Either<Failure, void>> syncPreferencesToBackend(String authToken);
}
