import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:logger/logger.dart';
import '../../../../core/constants/category_constants.dart';
import '../../domain/repositories/onboarding_repository.dart';
import 'onboarding_preferences_state.dart';

/// Cubit for managing onboarding preferences logic
class OnboardingPreferencesCubit extends Cubit<OnboardingPreferencesState> {
  final OnboardingRepository repository;
  final Logger logger;

  // Internal state
  final List<String> _selectedCategories = [];

  OnboardingPreferencesCubit({required this.repository, required this.logger})
    : super(const PreferencesInitialState()) {
    _loadExistingPreferences();
  }

  /// Load existing preferences (if user returns to this screen)
  Future<void> _loadExistingPreferences() async {
    final result = await repository.getLocalPreferences();

    result.fold(
      (failure) {
        // No preferences found - stay in initial state
        logger.d('No existing preferences found');
      },
      (preferences) {
        if (preferences != null && preferences.selectedCategories.isNotEmpty) {
          _selectedCategories.addAll(preferences.selectedCategories);
          emit(
            PreferencesSelectionState(
              selectedCategories: List.from(_selectedCategories),
              isNextEnabled: _selectedCategories.isNotEmpty,
            ),
          );
          logger.i(
            'Loaded existing preferences: ${preferences.selectedCategories}',
          );
        }
      },
    );
  }

  /// Toggle category selection
  void toggleCategory(String categoryKey) {
    // Validate category
    if (!CategoryConstants.isValidCategory(categoryKey)) {
      logger.w('Invalid category key: $categoryKey');
      return;
    }

    // Toggle selection
    if (_selectedCategories.contains(categoryKey)) {
      _selectedCategories.remove(categoryKey);
      logger.d('Removed category: $categoryKey');
    } else {
      _selectedCategories.add(categoryKey);
      logger.d('Added category: $categoryKey');
    }

    // Emit new state
    emit(
      PreferencesSelectionState(
        selectedCategories: List.from(_selectedCategories),
        isNextEnabled: _selectedCategories.isNotEmpty,
      ),
    );
  }

  /// Check if a category is selected
  bool isCategorySelected(String categoryKey) {
    return _selectedCategories.contains(categoryKey);
  }

  /// Clear all selections
  void clearSelections() {
    _selectedCategories.clear();
    emit(
      const PreferencesSelectionState(
        selectedCategories: [],
        isNextEnabled: false,
      ),
    );
    logger.i('Cleared all selections');
  }

  /// Skip onboarding (don't save preferences)
  void skipOnboarding() {
    logger.i('User skipped onboarding');
    emit(const PreferencesSkippedState());
  }

  /// Proceed to next step (save preferences)
  Future<void> proceedToNext() async {
    if (_selectedCategories.isEmpty) {
      logger.w('Cannot proceed with empty selection');
      return;
    }

    logger.i('Saving preferences: $_selectedCategories');

    // Emit saving state
    emit(
      PreferencesSavingState(
        selectedCategories: List.from(_selectedCategories),
      ),
    );

    // Save to local storage
    final result = await repository.savePreferencesLocally(_selectedCategories);

    result.fold(
      (failure) {
        logger.e('Failed to save preferences: ${failure.message}');
        emit(
          PreferencesSaveErrorState(
            failure: failure,
            selectedCategories: List.from(_selectedCategories),
          ),
        );
      },
      (_) {
        logger.i('Preferences saved successfully');
        emit(
          PreferencesSavedState(
            selectedCategories: List.from(_selectedCategories),
          ),
        );
      },
    );
  }

  /// Get current selection count
  int get selectionCount => _selectedCategories.length;

  /// Check if next button should be enabled
  bool get isNextEnabled => _selectedCategories.isNotEmpty;
}
