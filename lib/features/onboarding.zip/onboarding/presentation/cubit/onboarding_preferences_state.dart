import 'package:equatable/equatable.dart';
import '../../../../core/errors/failures.dart';

/// State for onboarding preferences screen
abstract class OnboardingPreferencesState extends Equatable {
  const OnboardingPreferencesState();
}

/// Initial state with empty selection
class PreferencesInitialState extends OnboardingPreferencesState {
  final List<String> selectedCategories;

  const PreferencesInitialState({this.selectedCategories = const []});

  @override
  List<Object?> get props => [selectedCategories];
}

/// State when user is selecting categories
class PreferencesSelectionState extends OnboardingPreferencesState {
  final List<String> selectedCategories;
  final bool isNextEnabled; // Computed: selectedCategories.isNotEmpty

  const PreferencesSelectionState({
    required this.selectedCategories,
    required this.isNextEnabled,
  });

  @override
  List<Object?> get props => [selectedCategories, isNextEnabled];
}

/// State when saving preferences
class PreferencesSavingState extends OnboardingPreferencesState {
  final List<String> selectedCategories;

  const PreferencesSavingState({required this.selectedCategories});

  @override
  List<Object?> get props => [selectedCategories];
}

/// State when save succeeded
class PreferencesSavedState extends OnboardingPreferencesState {
  final List<String> selectedCategories;

  const PreferencesSavedState({required this.selectedCategories});

  @override
  List<Object?> get props => [selectedCategories];
}

/// State when save failed
class PreferencesSaveErrorState extends OnboardingPreferencesState {
  final Failure failure;
  final List<String> selectedCategories; // For retry

  const PreferencesSaveErrorState({
    required this.failure,
    required this.selectedCategories,
  });

  @override
  List<Object?> get props => [failure, selectedCategories];
}

/// State when skipping onboarding
class PreferencesSkippedState extends OnboardingPreferencesState {
  const PreferencesSkippedState();

  @override
  List<Object?> get props => [];
}
