import 'package:dartz/dartz.dart';
import '../../../../core/errors/failures.dart';
import '../entities/user_entity.dart';
import '../repositories/auth_repository.dart';

class RegisterUseCase {
  final AuthRepository repository;
  RegisterUseCase(this.repository);

  Future<Either<Failure, UserEntity>> call({
    required String firstName,
    required String lastName,
    required String email,
    required String phoneNumber,
    required String password,
    required String passwordConfirmation,
    required String role,
  }) =>
      repository.register(
        firstName:            firstName,
        lastName:             lastName,
        email:                email,
        phoneNumber:          phoneNumber,
        password:             password,
        passwordConfirmation: passwordConfirmation,
        role:                 role,
      );
}
