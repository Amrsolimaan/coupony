import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:logger/logger.dart';
import '../../domain/use_cases/send_otp_use_case.dart';
import '../../domain/use_cases/verify_otp_use_case.dart';
import 'auth_state.dart';

/// Manages OTP send and verification flow
///
/// Flow:
/// 1. Screen opens with email pre-filled → sendOtp() called
/// 2. User enters 6-digit code → verifyOtp() called on submit
/// 3. On success → navSignal.toHome or toMerchantDash
/// 4. Resend → sendOtp() again (60-second cooldown)
class OtpCubit extends Cubit<AuthState> {
  final SendOtpUseCase sendOtpUseCase;
  final VerifyOtpUseCase verifyOtpUseCase;
  final Logger logger;

  DateTime? _lastSentAt;
  static const _resendCooldownSeconds = 60;

  OtpCubit({
    required this.sendOtpUseCase,
    required this.verifyOtpUseCase,
    required this.logger,
  }) : super(const AuthState());

  void _safeEmit(AuthState s) {
    if (!isClosed) emit(s);
  }

  // ════════════════════════════════════════════════════════
  // SEND OTP
  // ════════════════════════════════════════════════════════

  Future<void> sendOtp(String email) async {
    if (state.isLoading) return;

    logger.i('Sending OTP to: ${_maskEmail(email)}');
    _safeEmit(state.copyWith(
      isLoading: true,
      errorMessage: null,
      successMessage: null,
      navSignal: AuthNavigation.none,
      otpEmail: email,
    ));

    final result = await sendOtpUseCase(email);

    result.fold(
      (failure) {
        logger.e('Send OTP failed: ${failure.message}');
        _safeEmit(state.copyWith(
          isLoading: false,
          isOtpSent: false,
          errorMessage: failure.message,
        ));
      },
      (_) {
        logger.i('OTP sent successfully to ${_maskEmail(email)}');
        _lastSentAt = DateTime.now();
        _safeEmit(state.copyWith(
          isLoading: false,
          isOtpSent: true,
          otpEmail: email,
          successMessage: 'otp_sent_success',
        ));
      },
    );
  }

  // ════════════════════════════════════════════════════════
  // RESEND OTP
  // ════════════════════════════════════════════════════════

  Future<void> resendOtp() async {
    final email = state.otpEmail;
    if (email == null) {
      logger.w('Cannot resend OTP — no email in state');
      return;
    }

    if (_lastSentAt != null) {
      final elapsed = DateTime.now().difference(_lastSentAt!).inSeconds;
      if (elapsed < _resendCooldownSeconds) {
        final remaining = _resendCooldownSeconds - elapsed;
        logger.d('Resend cooldown active — $remaining seconds remaining');
        _safeEmit(state.copyWith(errorMessage: 'otp_resend_cooldown_$remaining'));
        return;
      }
    }

    await sendOtp(email);
  }

  // ════════════════════════════════════════════════════════
  // VERIFY OTP
  // ════════════════════════════════════════════════════════

  Future<void> verifyOtp({required String email, required String code}) async {
    if (state.isLoading) return;

    if (code.trim().isEmpty) {
      _safeEmit(state.copyWith(errorMessage: 'otp_empty_error'));
      return;
    }

    logger.i('Verifying OTP for: ${_maskEmail(email)}');
    _safeEmit(state.copyWith(
      isLoading: true,
      errorMessage: null,
      successMessage: null,
      navSignal: AuthNavigation.none,
    ));

    final result = await verifyOtpUseCase(email: email, code: code.trim());

    result.fold(
      (failure) {
        logger.e('OTP verification failed: ${failure.message}');
        _safeEmit(state.copyWith(
          isLoading: false,
          errorMessage: failure.message,
        ));
      },
      (user) {
        logger.i('OTP verified — role: ${user.role}');
        final nav = user.role == 'merchant'
            ? AuthNavigation.toMerchantDash
            : AuthNavigation.toHome;
        _safeEmit(state.copyWith(
          isLoading: false,
          user: user,
          isOtpSent: false,
          successMessage: 'otp_verified_success',
          navSignal: nav,
        ));
      },
    );
  }

  // ════════════════════════════════════════════════════════
  // NAVIGATION HELPERS
  // ════════════════════════════════════════════════════════

  void clearNavSignal() => _safeEmit(state.copyWith(navSignal: AuthNavigation.none));
  void clearMessages()  => _safeEmit(state.copyWith(errorMessage: null, successMessage: null));

  // ════════════════════════════════════════════════════════
  // COMPUTED HELPERS (for UI countdown timer)
  // ════════════════════════════════════════════════════════

  int get resendCooldownRemaining {
    if (_lastSentAt == null) return 0;
    final elapsed = DateTime.now().difference(_lastSentAt!).inSeconds;
    final remaining = _resendCooldownSeconds - elapsed;
    return remaining > 0 ? remaining : 0;
  }

  bool get canResend => resendCooldownRemaining == 0;

  // ════════════════════════════════════════════════════════
  // HELPERS
  // ════════════════════════════════════════════════════════

  String _maskEmail(String email) {
    final at = email.indexOf('@');
    if (at <= 1) return '****';
    return '${email[0]}****${email.substring(at)}';
  }
}
